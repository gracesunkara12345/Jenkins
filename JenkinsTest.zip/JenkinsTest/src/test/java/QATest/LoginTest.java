package QATest;

import org.testng.annotations.Test;
import Base.BaseClass;

public class LoginTest extends BaseClass {
	
	@Test
	public void testLogin() throws Exception
	{
		test = extent.createTest("LoginTest").assignAuthor("Grace").assignCategory("Functional");
		
		// Login
		loginOHAMS();
		
		//System.out.println("Test Pass");
		
		// Logout
		//logoutOHAMS();
	}

}
