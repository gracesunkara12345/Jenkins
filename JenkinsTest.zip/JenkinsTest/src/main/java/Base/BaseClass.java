package Base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import Utils.ReuseableMethods;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	
	public static ExtentReports extent;
	public static ExtentHtmlReporter html;
	public static ExtentTest test;
	public static WebDriver driver;
	public static ReuseableMethods reuse = new ReuseableMethods();
	protected static final Logger LOG = (Logger) LogManager.getLogger(BaseClass.class);
	
	@BeforeSuite
	public void generateReports()
	{
		extent = new ExtentReports();
		html = new ExtentHtmlReporter("./reports/" + "extent.html");
		extent.attachReporter(html);
		
		html.config().setTheme(Theme.STANDARD);
		String css = ".r-img {width: 75%;}";
		html.config().setCSS(css);
	}
	
	@BeforeMethod
	public void browserLaunch()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("http://192.168.1.96:8084/build/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//img[@style='max-height: 44px;']")).click();
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
	}
	
	@AfterMethod
	public void closeBrowser()
	{
		driver.close();
	}
	
	@AfterSuite
	public void tearDown()
	{
		extent.flush();
	}
	
	public void loginOHAMS() throws Exception, Exception
	{
		driver.findElement(By.xpath("//*[@type='text']")).sendKeys("21431");
		LOG.info("User Entered Username");
		test.pass("User Entered Username", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("Username")).build());
		driver.findElement(By.xpath("//*[@type='password']")).sendKeys("12345");
		LOG.info("User Entered password");
		test.pass("User Entered password", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("Password")).build());
		driver.findElement(By.xpath("//*[text()='SignIn']")).click();
		LOG.info("User SigIn Successfull");
		test.pass("User SigIn Successfull", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("SignIn")).build());

	}
	
	public void logoutOHAMS() throws Exception, Exception
	{
	   driver.findElement(By.xpath("//*[@data-bs-toggle='dropdown']")).click();
	   driver.findElement(By.xpath("//*[text()='Sign Out']")).click();
	   LOG.info("User Click on OK");
	   test.pass("User Click on OK", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("OKButton")).build());
	   driver.findElement(By.xpath("//*[text()='OK']")).click();
	   LOG.info("User Logout Successfull");
	   test.pass("User Logout Successfull", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("SignOut")).build());

	}

}
