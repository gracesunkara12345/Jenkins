package Utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Base.BaseClass;

public class ReuseableMethods extends BaseClass {
	
	public String addScreenshot(String filename) throws Exception
	{
		TakesScreenshot ts = (TakesScreenshot)driver;
		File srcFile = ts.getScreenshotAs(OutputType.FILE);
		File desFile = new File("./screenshots/" + filename + ".jpg");
		FileUtils.copyFile(srcFile, desFile);
		return desFile.getAbsolutePath();
	}

}
